<?php
echo "Why did you click that when I asked you specifically not to?\n\n\n\n\n";
echo '<img src="carrel.gif" alt="michael scott" style="width:600px;height:800px;">';
?>